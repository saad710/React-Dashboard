import React from 'react';

const NoMatch = () => {
    return (
        <div>
            <h2>route not found</h2>
        </div>
    );
};

export default NoMatch;